public class MyClass {
    private int age;
    private String name;

    public MyClass(int number, String name) {
        this.age = number;
        this.name = name;
        height = 0;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public void setAge(int number) {
        age = number;
    }

    public void setName(String name) {
        this.name = name;
    }
}
