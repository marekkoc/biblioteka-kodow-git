# would raise an error since it does not want to cast one type to the other implicitly.
my_var = 5 + "hello" 