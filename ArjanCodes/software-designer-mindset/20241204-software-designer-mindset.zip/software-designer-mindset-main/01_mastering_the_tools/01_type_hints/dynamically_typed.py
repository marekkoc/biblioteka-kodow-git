my_var = "Hello" # it is a string
my_var = 5 # now it is an integer; perfectly OK