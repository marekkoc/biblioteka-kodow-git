def times_2(value: int | float) -> float:
    return value * 2.0
