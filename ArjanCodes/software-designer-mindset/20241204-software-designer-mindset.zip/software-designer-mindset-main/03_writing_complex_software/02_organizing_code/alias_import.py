from package_1.file_1 import duplicate_function as f1_duplicate_function
from package_2.file_3 import duplicate_function as f2_duplicate_function
from module import VOWELS as V

f1_duplicate_function()
f2_duplicate_function()
print(V)
