from package_3.sub_package_2.file_6 import *
from package_2.file_3 import *


def main() -> None:
    duplicate_function()


if __name__ == "__main__":
    main()
