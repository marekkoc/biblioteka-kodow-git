# package_1
Regular package, with two files, file_1 and file_2

# package_2
Regular package, with a sub_package and a file

# package_3 
Namespace package, with two packages (Regular)