from numpy import *
from pandas import *


print(array([1, 2, 3, 4, 5]))
