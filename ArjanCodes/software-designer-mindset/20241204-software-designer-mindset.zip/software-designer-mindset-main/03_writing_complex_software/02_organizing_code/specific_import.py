from module import VOWELS
from package_1 import file_1
from package_1.file_1 import file_1_function
