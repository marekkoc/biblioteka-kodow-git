def file_3_function():
    print("package_2.file_3_function")


def duplicate_function():
    print("package_2.file_3.duplicate_function")
