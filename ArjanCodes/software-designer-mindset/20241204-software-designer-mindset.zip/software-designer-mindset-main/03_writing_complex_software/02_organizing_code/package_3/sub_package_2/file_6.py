def duplicate_function():
    print("package_3.sub_package_2.file_6.duplicate_function")
