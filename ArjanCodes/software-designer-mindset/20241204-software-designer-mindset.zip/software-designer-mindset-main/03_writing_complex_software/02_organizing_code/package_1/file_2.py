from .file_1 import file_1_function


def file_2_function():
    print("package_1.file_2_function")
    file_1_function()
