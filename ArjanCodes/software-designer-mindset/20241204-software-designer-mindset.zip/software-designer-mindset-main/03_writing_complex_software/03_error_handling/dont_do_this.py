try:
    something
except:
    pass
