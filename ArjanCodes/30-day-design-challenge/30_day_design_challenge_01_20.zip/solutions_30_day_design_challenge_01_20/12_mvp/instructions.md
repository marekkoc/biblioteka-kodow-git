## Change GUI to use Model View Presenter (MVP) architecture

For this challenge we have created a GUI that is coupled with the data processing
application you have seen before. You can see the code that implements the GUI in the `gui.py`.

## Challenge

For this challenge you need to refactor the `gui.py` code to use the Model-View-Presenter architecture.

## Solution (this should be sent afterwards with your explanation video (if applicable)
