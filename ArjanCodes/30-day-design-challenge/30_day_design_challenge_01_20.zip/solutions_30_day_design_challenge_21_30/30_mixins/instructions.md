## Make code as ugly as possible


## Challenge

For this challenge you should pick any code that is nicely designed and structured and try to make it as ugly as
possible. There's only one requirement, the code needs to run afterwards as well.

## Solution (this should be sent afterwards with your explanation video (if applicable)

Really? You need help with that? :-D










